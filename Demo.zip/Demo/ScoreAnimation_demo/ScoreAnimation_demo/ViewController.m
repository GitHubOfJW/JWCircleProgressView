//
//  ViewController.m
//  ScoreAnimation_demo
//
//  Created by 朱建伟 on 16/9/1.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//
#import "ZXCircleProgressView.h"
#import "ViewController.h"

@interface ViewController ()
/**
 *  view
 */
@property(nonatomic,strong)ZXCircleProgressView* circleProgressView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.view.backgroundColor = [UIColor redColor];
    
    self.view.layer.contents = (__bridge id _Nullable)([UIImage imageNamed:@"sm-bg"].CGImage);
    
    [self.circleProgressView addTarget:self action:@selector(starAnimation) forControlEvents:(UIControlEventTouchUpInside)];
    
    [self.view addSubview:self.circleProgressView];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    [self starAnimation];
}

-(void)starAnimation
{ 
    self.circleProgressView.startText =  @"🌞 00:00";//☼
    
    self.circleProgressView.endText = @"🌛 11:11";//☽
    
    self.circleProgressView.centerText = @"88";
    
    [self.circleProgressView starAnimationWithPartCount:5 partPercentBlock:^CGFloat(NSUInteger partIndex) {
        switch (partIndex%4) {
            case 0:
                return 0.1;
                break;
            case 1:
                return 0.18;
                break;
            case 2:
                return 0.1;
                break;
            case 3:
                return 0.15;
                break;
            default:
                return 0.2;
                break;
        }

    } parImageBlock:^UIImage * _Nonnull(NSUInteger partIndex) {
        switch (partIndex%6) {
            case 0:
                return [UIImage imageNamed:@"p_blue"];
                break;
            case 1:
                return [UIImage imageNamed:@"p_orange"];
                break;
            case 2:
                return [UIImage imageNamed:@"p_purple"];
                break;
            case 3:
                return [UIImage imageNamed:@"p_red"];
                break;
            case 4:
                return [UIImage imageNamed:@"p_lightBlue"];
                break;
            case 5:
                return [UIImage imageNamed:@"p_green"];
                break;
            default:
                return [UIImage imageNamed:@"p_green"];
                break;
        }
    } duration:0.5];
}

-(ZXCircleProgressView *)circleProgressView
{
    if (_circleProgressView==nil) {
        _circleProgressView = [[ZXCircleProgressView alloc] initWithFrame:CGRectMake(0, 100, self.view.bounds.size.width, self.view.bounds.size.width)];
        _circleProgressView.centerImage = [UIImage imageNamed:@"sm-time"];
    }
    return _circleProgressView;
}
@end
